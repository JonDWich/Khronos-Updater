-- @BRIEF: General Physics toggles
-- @USE: Place this in your game root (the same place as your default.xex file). Changes will take effect when going through a load screen.

local sec = 1
local meter = 100
Custom.Physics.Temp = {
  -- General params
  USE_HIGH_GRAVITY = true, -- Enables "high gravity mode", making jumps snappier.
  ENABLE_DROP_DASH = true, -- Enables Drop Dash by landing while holding the B button.
  USE_NEW_MACH_SPEED = true, -- Enables the Mach Speed rewrite. Disable to use Retail behavior with some basic physics integration
  -- Super Sonic params
  USE_SUPER_RING_REQ = true, -- Requires Sonic to have 50 rings before using the Rainbow Gem.
  USE_SUPER_CUTSCENE = true, -- Enables the brief cutscene when using the Rainbow Gem.
  -- Companion mod params
  IDLE_QUOTE_TIME = 30 * sec, -- Time between idle quotes. This is part of the companion mod.
}